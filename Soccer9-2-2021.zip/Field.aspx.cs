﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication1.BLL;

namespace WebApplication1
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           
            Lblmsg.Visible = false;
            MTHDFillRepeater();
            BttnUpdate.Visible = false;
        }
        dbSoccerStateEntities db = new dbSoccerStateEntities();
        protected void BtnSubmit_Click(object sender, EventArgs e)
        {
            if (!Empty())
            {
                string DummyValue = "0";
                FieldBLL obj = new FieldBLL();
                obj.Add(TxtFieldName.Text, float.Parse(DummyValue), float.Parse(DummyValue), DummyValue);
                db.SaveChanges();
                Clear();
                MTHDFillRepeater();
                Lblmsg.Visible = true;
                Lblmsg.Text = "Record Entered Successfully";
                Lblmsg.ForeColor = System.Drawing.Color.Green;
            }
           else
            {
                Lblmsg.Visible = true;
                Lblmsg.Text = "Fill All Fields";
                Lblmsg.ForeColor = System.Drawing.Color.Green;
            }
        }
        public void Clear()
        {
            TxtFieldName.Text = "";
            //TxtLenghtInYards.Text = "";
            //TxtWidhtInYards.Text = "";
            //TxtFieldLocation.Text = "";



        }
        public void MTHDFillRepeater()
        {
            Repeater1.DataSource = db.tblFields.ToList().OrderByDescending(p => p.FieldID);
            Repeater1.DataBind();

        }
        public bool Empty()
        {
           
            if (TxtFieldName.Text.Trim() == string.Empty )
            {
                Lblmsg.Visible = true;
                Lblmsg.Text = "Fill all fields";
                Lblmsg.ForeColor = System.Drawing.Color.Red;
                return true;

            }
            else
            {
                return false;
            }
        }

        protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
          {
            switch (e.CommandName)
            {

                case ("Edit"):

                    //==== Getting id of the selelected record(We have passed on link button's command argument property).
                    int id = Convert.ToInt32(e.CommandArgument);
                    HiddenField1.Value = id.ToString();
                    tblField obj1 = db.tblFields.FirstOrDefault(r => r.FieldID == id);


                    TxtFieldName.Text = obj1.FieldName;
                    //TxtLenghtInYards.Text = obj1.LenghtInYards.ToString();
                    //TxtWidhtInYards.Text = obj1.WidhtInYards.ToString();
                    //TxtFieldLocation.Text = obj1.FieldLocation;


                    BtnSubmit.Visible = false;
                    BttnUpdate.Visible = true;


                    break;
            }
        }

        protected void BtnUpdate_Click(object sender, EventArgs e)
        {
            try
            {

                int id = int.Parse(HiddenField1.Value);
                var row = db.tblFields.Where(a => a.FieldID == id).FirstOrDefault();
                if (row != null)
                {





                    row.FieldName = TxtFieldName.Text;
                    //row.LenghtInYards = float.Parse(TxtLenghtInYards.Text);
                    //row.WidhtInYards = float.Parse(TxtWidhtInYards.Text);
                    //row.FieldLocation = TxtFieldLocation.Text;

                    db.SaveChanges();




                    MTHDFillRepeater();

                    Clear();
                    Lblmsg.Visible = false;
                    Lblmsg.Text = "Record Updated Successfully";
                    Lblmsg.ForeColor = System.Drawing.Color.Green;


                    BtnSubmit.Visible = true;
                    BttnUpdate.Visible = false;
                }

            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }
    }
}