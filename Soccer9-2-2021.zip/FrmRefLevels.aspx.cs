﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class FrmRefLevels : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                MthdFillDrpRef();
            }
            BtnUpdate.Visible = false;
            lblmsg.Visible = false;
            mthdFillRepeater();
        }
        dbSoccerStateEntities db = new dbSoccerStateEntities();
        public void MthdFillDrpRef()
        {


            DrpRefree.DataSource = (from c in db.SpFillDrpRef() select new { c.RefereeID, c.Fullname }).ToList();
            DrpRefree.DataTextField = "Fullname";
            DrpRefree.DataValueField = "RefereeID";
            DrpRefree.DataBind();
        }

        public void mthdFillRepeater()
        {
         Repeater1.DataSource=  db.SpFillRepRefreeAtLevelsUpdated().ToList().OrderByDescending(p => p.RefereeID);
         Repeater1.DataBind();
        }
        protected void BtnSubmit_Click(object sender, EventArgs e)
        {
            int RefreeID = int.Parse(DrpRefree.SelectedValue.ToString());

            db.UpdateTblRefreeLevel(DrpLevel.SelectedValue,RefreeID);
            db.SaveChanges();
            lblmsg.Visible = true;
            lblmsg.Text = "Level Assigned Successfully";
            lblmsg.ForeColor = System.Drawing.Color.Green;
            mthdFillRepeater();
        }

        protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            switch (e.CommandName)
            {

                case ("Edit"):

                    //==== Getting id of the selelected record(We have passed on link button's command argument property).
                    int id = Convert.ToInt32(e.CommandArgument);
                    HiddenField1.Value = id.ToString();
                    tblReferee obj1 = db.tblReferees.FirstOrDefault(r => r.RefereeID == id);


                    DrpRefree.SelectedValue = obj1.RefereeID.ToString();
                    DrpLevel.SelectedValue = obj1.RefreeLevels.ToString();


                 



                    BtnSubmit.Visible = false;
                    BtnUpdate.Visible = true;


                    break;
            }
        }

        protected void BtnUpdate_Click(object sender, EventArgs e)
        {
            int RefreeID = int.Parse(DrpRefree.SelectedValue.ToString());

            db.UpdateTblRefreeLevel(DrpLevel.SelectedValue, RefreeID);
            db.SaveChanges();
            lblmsg.Visible = true;
            lblmsg.Text = "Assigned Level Updated";
            lblmsg.ForeColor = System.Drawing.Color.Green;
            mthdFillRepeater();


            BtnSubmit.Visible = true;
            BtnUpdate.Visible = false;
        }
    }
}