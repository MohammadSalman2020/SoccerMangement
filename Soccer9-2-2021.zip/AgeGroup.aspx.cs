﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication1.BLL;


namespace WebApplication1
{
    public partial class AgeGroup : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblmsg.Visible = false;
            MTHDFillRepeater();
            BtnUpdate.Visible = false;
        }
        dbSoccerStateEntities db = new dbSoccerStateEntities();
        protected void BtnSubmit_Click(object sender, EventArgs e)
        {
            if (!Empty())
            {
                AgeBLL obj = new AgeBLL();
                obj.Add(TxtAgeGroup.Text, TxtDivision.Text, txtDiff.Text, int.Parse(TxtRate.Text));
                db.SaveChanges();
                Clear();
                MTHDFillRepeater();
                lblmsg.Visible = true;
                lblmsg.Text = "Record Entered Successfully";
                lblmsg.ForeColor = System.Drawing.Color.Green;
            }
            else
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Fill All Fields";
                lblmsg.ForeColor = System.Drawing.Color.Green;
            }


        }
        public void MTHDFillRepeater()
        {
            Repeater1.DataSource = db.tblAgeGroups.ToList().OrderByDescending(p => p.AgeGroupID);
            Repeater1.DataBind();

        }
        public bool Empty()
        {
            if (TxtAgeGroup.Text.Trim() == string.Empty || TxtDivision.Text.Trim() == string.Empty || txtDiff.Text.Trim() == string.Empty || TxtRate.Text.Trim() == string.Empty)
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Fill all fields";
                lblmsg.ForeColor = System.Drawing.Color.Red;
                return true;

            }
            else
            {
                return false;
            }
        }
        public void Clear()
        {
            txtDiff.Text = "";
            TxtAgeGroup.Text = "";
            TxtDivision.Text = "";
            TxtRate.Text = "";
        }

        protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            switch (e.CommandName)
            {

                case ("Edit"):

                    //==== Getting id of the selelected record(We have passed on link button's command argument property).
                    int id = Convert.ToInt32(e.CommandArgument);
                    HiddenField1.Value = id.ToString();
                    tblAgeGroup obj1 = db.tblAgeGroups.FirstOrDefault(r => r.AgeGroupID == id);


                    TxtAgeGroup.Text = obj1.AgeGroup;
                    txtDiff.Text = obj1.Difficulty;
                    TxtDivision.Text = obj1.Division;
                    TxtRate.Text = obj1.Rate.ToString();

                    BtnSubmit.Visible = false;
                    BtnUpdate.Visible = true;


                    break;
            }
        }

        protected void BtnUpdate_Click(object sender, EventArgs e)
        {
            try
            {

                int id = int.Parse(HiddenField1.Value);
                var row = db.tblAgeGroups.Where(a => a.AgeGroupID == id).FirstOrDefault();
                if (row != null)
                {





                    row.AgeGroup = TxtAgeGroup.Text;
                    row.Difficulty = txtDiff.Text;

                    row.Rate = int.Parse(TxtRate.Text);
                    row.Division = TxtDivision.Text;

                    db.SaveChanges();




                    MTHDFillRepeater();

                    Clear();
                    lblmsg.Visible = false;
                    lblmsg.Text = "Record Updated Successfully";
                    lblmsg.ForeColor = System.Drawing.Color.Green;

                    BtnSubmit.Visible = true;
                    BtnUpdate.Visible = false;
                }

            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }
    }
}