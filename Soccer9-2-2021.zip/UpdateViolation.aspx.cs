﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication1.BLL;

namespace WebApplication1
{
    public partial class UpdateViolation : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblmsg.Visible = false;
            if (!IsPostBack)
            {
                FillDrops();
                MthdFillDrpPlayer();
            }
            MthdShowHideDivs();
            DivRedCard.Visible = false;
            DivYellowCard.Visible = false;
        }
            public void FillDrops()
            
                {
                    DrpMatch.DataSource = (from c in db.tblMatches select new { c.MatchID, c.MatchTitle }).ToList();
                    DrpMatch.DataTextField = "MatchTitle";
                    DrpMatch.DataValueField = "MatchID";
                    DrpMatch.DataBind();

                }
        public void MthdFillDrpPlayer()
                {
                    DrpPlayer.DataSource = (from c in db.tblPlayers select new { c.PlayerID, c.ShirtNo}).ToList();
                    DrpPlayer.DataTextField = "ShirtNo";
                    DrpPlayer.DataValueField = "PlayerID";
                    DrpPlayer.DataBind();

                }




            

        
        dbSoccerStateEntities db = new dbSoccerStateEntities();
        int x;
        protected void BtnSubmit_Click(object sender, EventArgs e)
        {
            x = 0;
        
            if (!Empty()) 
            {
                
                x=int.Parse(DrpSelect.SelectedIndex.ToString());
                int MatchID = int.Parse(DrpMatch.SelectedValue.ToString());
                int PlayerID = int.Parse(DrpPlayer.SelectedValue.ToString());

                if (x == 1)
                {



                    db.SpInsertInViolaton("Yellow", chkbox_Yellow.SelectedItem.ToString(), MatchID, PlayerID, TxtLeadUpToIncident.InnerText, TxtIncident.InnerText,
                          TxtPositionDetail.InnerText, TxtAbusiveLanguage.InnerText, TxtBefore.Text, TxtDuring.Text, TxtAfter.Text);
                        db.SaveChanges();
                    
                }

                
             
           else if (x==2)
           {
               db.SpInsertInViolaton("Red", chkbox_Red.SelectedItem.ToString(), MatchID, PlayerID, TxtLeadUpToIncident.InnerText, TxtIncident.InnerText,
                  TxtPositionDetail.InnerText, TxtAbusiveLanguage.InnerText, TxtBefore.Text, TxtDuring.Text, TxtAfter.Text);
               db.SaveChanges();
           }

               

              
         

               


                Clear();
                lblmsg.Visible = true;
                lblmsg.Text = "Record Entered Successfully";
                lblmsg.ForeColor = System.Drawing.Color.Green;
            }
           else
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Fill All Fields";
                lblmsg.ForeColor = System.Drawing.Color.Green;

            }
        }
        public bool Empty()
        {
            if (DrpMatch.SelectedValue.Trim() == string.Empty || DrpPlayer.SelectedValue.Trim() == string.Empty || DrpSelect.SelectedValue.Trim() == string.Empty || TxtBefore.Text.Trim() == string.Empty || TxtDuring.Text.Trim() == string.Empty || TxtAfter.Text.Trim() == string.Empty || TxtIncident.InnerText.Trim() == string.Empty || TxtPositionDetail.InnerText.Trim() == string.Empty || TxtAbusiveLanguage.InnerText.Trim() == string.Empty)
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Fill all fields";
                lblmsg.ForeColor = System.Drawing.Color.Red;
                return true;

            }
            else
            {
                return false;
            }
        }
        public void Clear()
        {

            TxtBefore.Text = "";
            TxtDuring.Text = "";
            TxtAfter.Text = "";
            TxtIncident.InnerText = "";
            TxtPositionDetail.InnerText = "";
            TxtAbusiveLanguage.InnerText = "";

        }

        protected void DrpSelect_SelectedIndexChanged(object sender, EventArgs e)
        {
            MthdShowHideDivs();

        }
        public void MthdShowHideDivs()
        {
            if (DrpSelect.SelectedValue == "Yellow Card Information")
            {
                DivYellowCard.Visible = true;
            }
            else if (DrpSelect.SelectedValue == "Red Card Information")
            {
                DivRedCard.Visible = true;
            }
        }

    }
}