﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication1.BLL;

namespace WebApplication1
{
    public partial class Player : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblmsg.Visible = false;
            MTHDFillRepeater();
            BtnUpdate.Visible = false;
            if (!IsPostBack)
            {
                FillDrops();
            }
            

        }
        public void FillDrops()
        {
            DrpTeam.DataSource = (from c in db.tblTeams select new { c.TeamID, c.Name }).ToList();
            DrpTeam.DataTextField = "Name";
            DrpTeam.DataValueField = "TeamID";
            DrpTeam.DataBind();


        }
        dbSoccerStateEntities db = new dbSoccerStateEntities();
        protected void BtnSubmit_Click(object sender, EventArgs e)
        {
            if (!Empty())
            {
                PlayerBLL obj = new PlayerBLL();
                obj.Add(int.Parse(DrpTeam.SelectedValue.ToString()), TxtFirstName.Text, TxtLastName.Text,TxtShirtNo.Text);
                db.SaveChanges();
                Clear();
                MTHDFillRepeater();
                lblmsg.Visible = true;
                lblmsg.Text = "Record Entered Successfully";
                lblmsg.ForeColor = System.Drawing.Color.Green;
            }
            else
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Fill All Fields";
                lblmsg.ForeColor = System.Drawing.Color.Green;
            }


        }
        public void MTHDFillRepeater()
        {
            Repeater1.DataSource = db.tblPlayers.ToList().OrderByDescending(p => p.PlayerID);
            Repeater1.DataBind();

        }
        public bool Empty()
        {
            if (DrpTeam.SelectedValue.Trim() == string.Empty || TxtFirstName.Text.Trim() == string.Empty || TxtLastName.Text.Trim() == string.Empty || TxtShirtNo.Text.Trim() == string.Empty)
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Fill all fields";
                lblmsg.ForeColor = System.Drawing.Color.Red;
                return true;

            }
            else
            {
                return false;
            }
        }

        public void Clear()
        {

            TxtFirstName.Text = "";
            TxtLastName.Text = "";
            TxtShirtNo.Text = "";
        }

        protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            switch (e.CommandName)
            {

                case ("Edit"):

                    //==== Getting id of the selelected record(We have passed on link button's command argument property).
                    int id = Convert.ToInt32(e.CommandArgument);
                    HiddenField1.Value = id.ToString();
                    tblPlayer obj1 = db.tblPlayers.FirstOrDefault(r => r.PlayerID == id);


                    DrpTeam.SelectedValue = obj1.TeamID.ToString();
                    TxtFirstName.Text = obj1.FirstName;
                    TxtLastName.Text = obj1.LastName;
                    TxtShirtNo.Text = obj1.ShirtNo;


                    BtnSubmit.Visible = false;
                    BtnUpdate.Visible = true;


                    break;
            }
        }

        protected void BtnUpdate_Click(object sender, EventArgs e)
        {
            try
            {

                int id = int.Parse(HiddenField1.Value);
                var row = db.tblPlayers.Where(a => a.PlayerID == id).FirstOrDefault();
                if (row != null)
                {





                    row.TeamID = int.Parse(DrpTeam.SelectedValue.ToString());
                    row.FirstName = TxtFirstName.Text;
                    row.LastName = TxtLastName.Text;
                    row.ShirtNo = TxtShirtNo.Text;


                    db.SaveChanges();





                    MTHDFillRepeater();

                    Clear();
                    lblmsg.Visible = false;
                    lblmsg.Text = "Record Updated Successfully";
                    lblmsg.ForeColor = System.Drawing.Color.Green;

                    BtnSubmit.Visible = true;
                    BtnUpdate.Visible = false;
                }

            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

    }
}