﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication1;
namespace _360cleaning
{
    public partial class Frmlogin : System.Web.UI.Page
    {
        dbSoccerStateEntities db = new dbSoccerStateEntities();
        protected void BtnLogin_Click(object sender, EventArgs e)
        {
            if (IsUser(TxtUserName.Text, TxtPassword.Text))
            {
                Session["Email"] = TxtUserName.Text;
                


                Response.Redirect("Dashboard.aspx");  
            }
            else
            {
                Label1.Text = "Incorrect Password";
                Label1.ForeColor = System.Drawing.Color.White;
            }
        }


        public bool IsUser(string Email, string Password)
        {
            var rec = db.tblLogins.Where(a => a.Email == Email && a.C_Password == Password).FirstOrDefault();
            if (rec != null)
            {
                Session["RoleID"] = rec.RoleID.ToString();
                Session["Name"] = rec.Username;
                Session["RefID"] = rec.SystemUser;
                return true;
            }
            else
            {
                return false;
            }
        }
       
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}