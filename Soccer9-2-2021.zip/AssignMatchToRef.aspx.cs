﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class AssignMatchToRef : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                MthdFillDrpMatch();
                MthdFillDrpRef();
            }
            MthdFillRepeater();
            lblmsg.Visible = false;
            BtnUpdate.Visible = false;
        }
        dbSoccerStateEntities db = new dbSoccerStateEntities();
        public void MthdFillDrpMatch()
        {
            DrpMatch.DataSource = (from c in db.tblMatches select new { c.MatchID, c.MatchTitle }).ToList();
            DrpMatch.DataTextField = "MatchTitle";
            DrpMatch.DataValueField = "MatchID";
            DrpMatch.DataBind();
        }
        public void MthdFillDrpRef()
        {
   

            DrpRef.DataSource = (from c in db.SpFillDrpRef() select new { c.RefereeID, c.Fullname }).ToList();
            DrpRef.DataTextField = "Fullname";
            DrpRef.DataValueField = "RefereeID";
            DrpRef.DataBind();
        }
        public void MthdFillRepeater()
        {
            Repeater1.DataSource = db.SpFillRepeater().ToList().OrderByDescending(p => p.RequestID);
            Repeater1.DataBind();
        }

        protected void BtnSubmit_Click(object sender, EventArgs e)
        {
            if(!Empty())
            {
                tblMatchAssignRequest obj = new tblMatchAssignRequest();

                obj.RequestFrom = int.Parse(Session["RoleID"].ToString());

                obj.RequestTo = int.Parse(DrpRef.SelectedValue.ToString());

                obj.matchID = int.Parse(DrpMatch.SelectedValue.ToString());

                DateTime Startdate = DateTime.Parse(txtDate.Text);
                obj.requestDate = Startdate;

                obj.Status = false;

                db.tblMatchAssignRequests.Add(obj);
                db.SaveChanges();

                MthdFillRepeater();

                lblmsg.Visible = true;
                lblmsg.Text = "Record Inserted";
                lblmsg.ForeColor = System.Drawing.Color.Green;
                txtDate.Text = "";
            }
            else
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Fill all fields";
                lblmsg.ForeColor = System.Drawing.Color.Red;
            }
        }
        public bool Empty()
        {
            if (txtDate.Text.Trim() == string.Empty || DrpMatch.SelectedValue.Trim() == string.Empty || DrpRef.SelectedValue.Trim() == string.Empty)
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Fill all fields";
                lblmsg.ForeColor = System.Drawing.Color.Red;
                return true;

            }
            else
            {
                return false;
            }
        }

        protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            switch (e.CommandName)
            {

                case ("Edit"):

                    //==== Getting id of the selelected record(We have passed on link button's command argument property).
                    int id = Convert.ToInt32(e.CommandArgument);
                    HiddenField1.Value = id.ToString();
                    tblMatchAssignRequest obj1 = db.tblMatchAssignRequests.FirstOrDefault(r => r.RequestID == id);


                    DrpMatch.SelectedValue = obj1.matchID.ToString();
                    DrpRef.SelectedValue = obj1.RequestTo.ToString();


                    string date = obj1.requestDate.ToString();
                    txtDate.Text = DateTime.Parse(date).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
                   


                    BtnSubmit.Visible = false;
                    BtnUpdate.Visible = true;


                    break;
            }
        }

        protected void BtnUpdate_Click(object sender, EventArgs e)
        {
            try
            {

                int id = int.Parse(HiddenField1.Value);
                var row = db.tblMatchAssignRequests.Where(a => a.RequestID == id).FirstOrDefault();
                if (row != null)
                {




                  
                    row.RequestTo = int.Parse(DrpRef.SelectedValue.ToString());
                    row.matchID = int.Parse(DrpMatch.SelectedValue.ToString());

                    row.requestDate = DateTime.Parse(txtDate.Text);
             


                    db.SaveChanges();





                    MthdFillRepeater();

                    txtDate.Text = "";
                    lblmsg.Visible = false;
                    lblmsg.Text = "Record Updated Successfully";
                    lblmsg.ForeColor = System.Drawing.Color.Green;

                    BtnSubmit.Visible = true;
                    BtnUpdate.Visible = false;
                }

            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }
    }
}