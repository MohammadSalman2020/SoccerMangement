﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication1.BLL;
using System.Globalization;

namespace WebApplication1
{
    public partial class Match : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblmsg.Visible = false;
            MTHDFillRepeater();
            BtnUpdate.Visible = false;
            if (!IsPostBack)
            {
                FillDrops();
            }
        }
        public void FillDrops()
            
        {
            {
                DrpField.DataSource = (from c in db.tblFields select new { c.FieldID, c.FieldName }).ToList();
                DrpField.DataTextField = "FieldName";
                DrpField.DataValueField = "FieldID";
                DrpField.DataBind();

            }

            {
                DrpAgeGroup.DataSource = (from c in db.tblAgeGroups select new { c.AgeGroupID, c.AgeGroup }).ToList();
                DrpAgeGroup.DataTextField = "AgeGroup";
                DrpAgeGroup.DataValueField = "AgeGroupID";
                DrpAgeGroup.DataBind();
            }

            {
                DrpTeamA.DataSource = (from c in db.tblTeams select new { c.TeamID, c.Name ,c.IsSuspended}).ToList().Where(p=>p.IsSuspended!=true);
                DrpTeamA.DataTextField = "Name";
                DrpTeamA.DataValueField = "TeamID";
                DrpTeamA.DataBind();
            }

            {
                DrpTeamB.DataSource = (from c in db.tblTeams select new { c.TeamID, c.Name ,c.IsSuspended}).ToList().Where(p => p.IsSuspended != true);
                DrpTeamB.DataTextField = "Name";
                DrpTeamB.DataValueField = "TeamID";
                DrpTeamB.DataBind();
            }


        }



        dbSoccerStateEntities db = new dbSoccerStateEntities(); 
        protected void BtnSubmit_Click(object sender, EventArgs e)
        {
            if(!Empty())
            {
                MatchBLL obj = new MatchBLL();
                obj.Add(TxtMatchTitle.Text, int.Parse(DrpField.SelectedValue.ToString()), int.Parse(DrpAgeGroup.SelectedValue.ToString()), int.Parse(DrpTeamA.SelectedValue.ToString()), int.Parse(DrpTeamB.SelectedValue.ToString()), DateTime.Parse(TxtMAtchDate.Text), DateTime.Now.ToString("H:mm tt").ToString());
                db.SaveChanges();
                Clear();
                MTHDFillRepeater();
                lblmsg.Visible = true;
                lblmsg.Text = "Record Entered Successfully";
                lblmsg.ForeColor = System.Drawing.Color.Green;

            }
            else
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Fill All Fields";
                lblmsg.ForeColor = System.Drawing.Color.Green;



            }
           

        }
        public void MTHDFillRepeater()
        {
            if(Role.isRefree())
            {
                int id = int.Parse(Session["RefID"].ToString());
                Repeater1.DataSource = db.SpFillRepMatchRefUpdats1(id).ToList().OrderByDescending(p => p.MatchID);
                Repeater1.DataBind();
            }
            else
            {
                Repeater1.DataSource = db.SpFillRepeaterAtMatch().ToList().OrderByDescending(p => p.MatchID);
                Repeater1.DataBind();
            }
        

        }
        public bool Empty()
        {
            if (TxtMatchTitle.Text.Trim() == string.Empty || DrpField.SelectedValue.Trim() == string.Empty || DrpAgeGroup.SelectedValue.Trim() == string.Empty || DrpTeamA.SelectedValue.Trim() == string.Empty || DrpTeamB.SelectedValue.Trim() == string.Empty || TxtMAtchDate.Text == string.Empty || TxtMatchTime.Text == string.Empty )
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Fill all fields";
                lblmsg.ForeColor = System.Drawing.Color.Red;
                return true;

            }
            else
            {
                return false;
            }
        }
        public void Clear()
        {

            TxtMatchTitle.Text = "";
            TxtMAtchDate.Text = "";
            TxtMatchTime.Text = "";
        }

        protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            switch (e.CommandName)
            {

                case ("Edit"):

                    //==== Getting id of the selelected record(We have passed on link button's command argument property).
                    int id = Convert.ToInt32(e.CommandArgument);
                    HiddenField1.Value = id.ToString();
                    tblMatch obj1 = db.tblMatches.FirstOrDefault(r => r.MatchID == id);


                    TxtMatchTitle.Text = obj1.MatchTitle;
                    DrpField.SelectedValue = obj1.FieldID.ToString();
                    DrpAgeGroup.SelectedValue = obj1.AgeGroup.ToString();
                    DrpTeamA.SelectedValue = obj1.Team1.ToString();
                    DrpTeamB.SelectedValue = obj1.Team2.ToString();
                    string date = obj1.MatchDate.ToString();
                    TxtMAtchDate.Text = DateTime.Parse(date).ToString("yyyy-MM-dd",CultureInfo.InvariantCulture);
                    TxtMatchTime.Text = obj1.MatchTime;


                    BtnSubmit.Visible = false;
                    BtnUpdate.Visible = true;


                    break;
            }
        }

        protected void BtnUpdate_Click(object sender, EventArgs e)
        {
            try
            {

                int id = int.Parse(HiddenField1.Value);
                var row = db.tblMatches.Where(a => a.MatchID == id).FirstOrDefault();
                if (row != null)
                {




                    row.MatchTitle = TxtMatchTitle.Text;
                    row.FieldID = int.Parse(DrpField.SelectedValue.ToString());
                    row.AgeGroup = int.Parse(DrpAgeGroup.SelectedValue.ToString());
                    row.Team1 = int.Parse(DrpTeamA.SelectedValue.ToString());
                    row.Team2 = int.Parse(DrpTeamB.SelectedValue.ToString());
                    row.MatchDate = DateTime.Parse(TxtMAtchDate.Text);
                    row.MatchTime = TxtMatchTime.Text;


                    db.SaveChanges();





                    MTHDFillRepeater();

                    Clear();
                    lblmsg.Visible = false;
                    lblmsg.Text = "Record Updated Successfully";
                    lblmsg.ForeColor = System.Drawing.Color.Green;

                    BtnSubmit.Visible = true;
                    BtnUpdate.Visible = false;
                }

            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }
    }
}