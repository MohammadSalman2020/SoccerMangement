﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication1.BLL;

namespace WebApplication1
{
    public partial class FrmTeamPlayerSuspend : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ShowHide();
                mthdFillDrpTeam();
                mthdFillDrpPlayer();

            }
            mthdFillRepeater();
            mthdFillRepeater1();

            lblmsg.Visible = false;


            DrpPlayer.Visible = false;
            DrpTeam.Visible = false;

            lblplayer.Visible = false;
            lblTeam.Visible = false;

        }
        dbSoccerStateEntities db = new dbSoccerStateEntities();
        int x;

        protected void DrpSelect_SelectedIndexChanged(object sender, EventArgs e)
        {
            ShowHide();

        }
        public void ShowHide()
        {
            x = DrpSelect.SelectedIndex;

            if (x == 1)
            {
                DrpPlayer.Visible = true;
                lblplayer.Visible = true;

            }
            else if (x == 2)
            {
                DrpTeam.Visible = true;
                lblTeam.Visible = true;

            }
        }
        public void mthdFillDrpTeam()
        {
            DrpTeam.DataSource = (from c in db.tblTeams select new { c.TeamID, c.Name }).ToList();
            DrpTeam.DataTextField = "Name";
            DrpTeam.DataValueField = "TeamID";
            DrpTeam.DataBind();

        }
        public void mthdFillDrpPlayer()
        {
            DrpPlayer.DataSource = (from c in db.tblPlayers select new { c.PlayerID, c.FirstName }).ToList();
            DrpPlayer.DataTextField = "FirstName";
            DrpPlayer.DataValueField = "PlayerID";
            DrpPlayer.DataBind();
        }

        public void mthdFillRepeater()
        {

            Repeater1.DataSource = db.SpSuspendRepeaterPlayerupdated().ToList().OrderByDescending(p => p.PlayerID);
            Repeater1.DataBind();

        }

        public void mthdFillRepeater1()
        {

            Repeater2.DataSource = db.SpSuspendRepeaterTeamupdated().ToList().OrderByDescending(p => p.TeamID);
            Repeater2.DataBind();

        }
        protected void BtnSubmit_Click(object sender, EventArgs e)
        {
            x = DrpSelect.SelectedIndex;
            if (x == 1)
            {
                if (CheckBox.Checked == true)
                {
                    db.SpSuspendPlayer(int.Parse(DrpPlayer.SelectedValue.ToString()), true);
                    db.SaveChanges();
                    lblmsg.Visible = true;
                    lblmsg.Text = "Player Suspended";
                    lblmsg.ForeColor = System.Drawing.Color.Green;
                }
                else if (CheckBox.Checked == false)
                {
                    db.SpSuspendPlayer(int.Parse(DrpPlayer.SelectedValue.ToString()), false);
                    db.SaveChanges();
                    lblmsg.Visible = true;
                    lblmsg.Text = "Player un-spended";
                    lblmsg.ForeColor = System.Drawing.Color.Green;
                }

            }
            else if (x == 2)
            {
                if (CheckBox.Checked == true)
                {
                    db.SpSuspendTeam(int.Parse(DrpTeam.SelectedValue.ToString()), true);
                    db.SaveChanges();
                    lblmsg.Visible = true;
                    lblmsg.Text = "Team un-uspended";
                    lblmsg.ForeColor = System.Drawing.Color.Green;
                }
                else if (CheckBox.Checked == false)
                {
                    db.SpSuspendTeam(int.Parse(DrpTeam.SelectedValue.ToString()), false);
                    db.SaveChanges();
                    lblmsg.Visible = true;
                    lblmsg.Text = "Team un-suspended";
                    lblmsg.ForeColor = System.Drawing.Color.Green;
                }
            }
            mthdFillRepeater();
            mthdFillRepeater1();
        }

        protected void DrpTeam_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void DrpPlayer_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            switch (e.CommandName)
            {

                case ("Edit"):
                  
                  int id = Convert.ToInt32(e.CommandArgument);
                    HiddenField1.Value = id.ToString();


                    try
                    {

                        //int id = int.Parse(HiddenField1.Value);
                        //HiddenField1.Value = id.ToString();
                        var row = db.tblPlayers.Where(a => a.PlayerID == id).FirstOrDefault();
                        if (row != null)
                        {




                            row.IsSuspended = false;



                            db.SaveChanges();





                            mthdFillRepeater();


                            lblmsg.Visible = false;
                            lblmsg.Text = "Record Updated Successfully";
                            lblmsg.ForeColor = System.Drawing.Color.Green;



                        }

                    }
                    catch (Exception ex)
                    {
                        ex.Message.ToString();
                    }


                    break;



            }
        }

        protected void Repeater2_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            switch (e.CommandName)
            {
                     
                case ("Edit"):

                       int id = Convert.ToInt32(e.CommandArgument);
                    HiddenField1.Value = id.ToString();

                    try
                    {

                       
                        var row = db.tblTeams.Where(a => a.TeamID == id).FirstOrDefault();
                        if (row != null)
                        {




                            row.IsSuspended = false;



                            db.SaveChanges();





                            mthdFillRepeater1();


                            lblmsg.Visible = false;
                            lblmsg.Text = "Record Updated Successfully";
                            lblmsg.ForeColor = System.Drawing.Color.Green;



                        }

                    }
                    catch (Exception ex)
                    {
                        ex.Message.ToString();
                    }


                    break;



            }
        }
    }
}