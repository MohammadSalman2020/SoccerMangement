﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication1.BLL;

namespace WebApplication1
{
    public partial class Refree : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            {

                lblmsg.Visible = false;
                MTHDFillRepeater();
                BtnUpdate.Visible = false;

                //var obj = db.tblReferees.Where(a => a.RefereeID ==1).FirstOrDefault();

                //string x = obj.IsAvailable.ToString();

                //string y = x;
            }

        }
        dbSoccerStateEntities db = new dbSoccerStateEntities();

        protected void BtnSubmit_Click(object sender, EventArgs e)
        {
            

            tblReferee Obj = new tblReferee();
            Obj.FirstName = TxtFirstName.Text;
            Obj.LastName = TxtLastName.Text;
            if (CheckBox1.Checked)
            {
                Obj.IsAvailable = true;
            }
            else
            {
                Obj.IsAvailable = false;
            }


            db.tblReferees.Add(Obj);

    db.SaveChanges();
    MTHDFillRepeater();
        }
        public void Clear()
        {
            TxtFirstName.Text = "";
            TxtLastName.Text = "";
            

        }
        public void MTHDFillRepeater()
        {
            if(Role.isRefree())
            {
                int id  = int.Parse(Session["RefID"].ToString());
                Repeater1.DataSource = db.tblReferees.ToList().Where(p=>p.RefereeID==id).OrderByDescending(p => p.RefereeID);
                Repeater1.DataBind();

            }

            else
            {
                Repeater1.DataSource = db.tblReferees.ToList().OrderByDescending(p => p.RefereeID);
                Repeater1.DataBind();

            }
          

        }
        public bool Empty()
        {
            if (TxtFirstName.Text.Trim() == string.Empty || TxtLastName.Text.Trim() == string.Empty )
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Fill all fields";
                lblmsg.ForeColor = System.Drawing.Color.Red;
                return true;

            }
            else
            {
                return false;
            }
        }

        protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
           
        }

        protected void BtnUpdate_Click(object sender, EventArgs e)
        {
             try
            {

                int id = int.Parse(HiddenField1.Value);
                var row = db.tblReferees.Where(a => a.RefereeID == id).FirstOrDefault();
                if (row != null)
                {
                    row.FirstName = TxtFirstName.Text;
                    row.LastName = TxtLastName.Text;
                    if (CheckBox1.Checked)
                    {
                        row.IsAvailable = true;
                    }
                    else
                    {
                        row.IsAvailable = false;
                    }

                    
                    db.SaveChanges();




                    MTHDFillRepeater();

                    Clear();
                    lblmsg.Visible = false;
                    lblmsg.Text = "Record Updated Successfully";
                    lblmsg.ForeColor = System.Drawing.Color.Green;

                    BtnSubmit.Visible = true;
                    BtnUpdate.Visible = false;
                }

            }
             catch (Exception ex)
             {
                 ex.Message.ToString();
             }
        }

        protected void Repeater1_ItemCommand1(object source, RepeaterCommandEventArgs e)
        {
            switch (e.CommandName)
            {

                case ("Edit"):

                    //==== Getting id of the selelected record(We have passed on link button's command argument property).
                    int id = Convert.ToInt32(e.CommandArgument);
                    HiddenField1.Value = id.ToString();
                    tblReferee obj1 = db.tblReferees.FirstOrDefault(r => r.RefereeID == id);


                    TxtFirstName.Text = obj1.FirstName;
                    TxtLastName.Text = obj1.LastName;
                    
                    if(obj1.IsAvailable==true)
                    {
                        CheckBox1.Checked = true;
                    }
                    else
                    {
                        CheckBox1.Checked = false;
                    }


                    BtnSubmit.Visible = false;
                    BtnUpdate.Visible = true;


                    break;
            }
        }


    }
}