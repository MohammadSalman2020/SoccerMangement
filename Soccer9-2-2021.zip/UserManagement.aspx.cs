﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication1.BLL;

namespace WebApplication1
{
    public partial class MasterPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                MthdFillDrpRole();
                MthdFillDrpRef();
            }
            lblmsg.Visible = false;
            DrpRef.Visible = false;
            lblRef.Visible = false;
        }
        dbSoccerStateEntities db = new dbSoccerStateEntities();

        public void MthdFillDrpRole()
        {
            DrpRole.DataSource = (from c in db.tblRoles select new { c.RoleID, c.RoleDesc }).ToList();
            DrpRole.DataValueField = "RoleID";
            DrpRole.DataTextField = "RoleDesc";
            DrpRole.DataBind();
        }
        public void MthdFillDrpRef()
        {


            DrpRef.DataSource = (from c in db.SpFillDrpRef() select new { c.RefereeID, c.Fullname }).ToList();
            DrpRef.DataTextField = "Fullname";
            DrpRef.DataValueField = "RefereeID";
            DrpRef.DataBind();
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            if (int.Parse(DrpRole.SelectedValue.ToString()) == 4)
            {
                tblLogin obj = new tblLogin();

                obj.RoleID = int.Parse(DrpRole.SelectedValue.ToString());
                obj.SystemUser = int.Parse(DrpRef.SelectedValue.ToString());
                obj.Email = txtEmail.Text;
                obj.C_Password = txtPassword.Text;
                obj.Username = txtUserName.Text;

                db.tblLogins.Add(obj);
                db.SaveChanges();

            }

            if (!Empty())
            {
                UserManagement obj = new UserManagement();
                obj.Add(txtEmail.Text, txtPassword.Text, int.Parse(DrpRole.SelectedValue.ToString()),txtUserName.Text);
                db.SaveChanges();
                Clear();
                lblmsg.Visible = true;
                lblmsg.Text = "Record Entered Successfully";
                lblmsg.ForeColor = System.Drawing.Color.Green;
            }
            else
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Fill All Fields";
                lblmsg.ForeColor = System.Drawing.Color.Green;
            }
        }
        public bool Empty()
        {
            if (txtEmail.Text.Trim() == string.Empty || txtPassword.Text.Trim() == string.Empty || DrpRole.SelectedValue.Trim() == string.Empty || txtUserName.Text.Trim() == string.Empty)
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Fill all fields";
                lblmsg.ForeColor = System.Drawing.Color.Red;
                return true;

            }
            else
            {
                return false;
            }
        }
        public void Clear()
        {
            txtEmail.Text = "";
            txtPassword.Text = "";
        }
        int x;
        protected void DrpRef_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        protected void DrpRole_SelectedIndexChanged(object sender, EventArgs e)
        {

            x = int.Parse(DrpRole.SelectedValue.ToString());
            if (x == 4)
            {
                DrpRef.Visible = true;
                lblRef.Visible = true;
            }
        }
    }
}