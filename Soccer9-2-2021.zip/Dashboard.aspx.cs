﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class Dashboard : System.Web.UI.Page
    {
        dbSoccerStateEntities db = new dbSoccerStateEntities();
        protected void Page_Load(object sender, EventArgs e)
        {
          if(!IsPostBack)
          {
              DashboardData();
          }
        }
        public void DashboardData()
        {
            var totalTeam = db.tblTeams.Count(a => a.TeamID > 0).ToString();
            lblTeam.Text = totalTeam;

            var totalRef = db.tblReferees.Count(a => a.RefereeID > 0).ToString();
            lblRef.Text = totalRef;

            string color = "Yellow";

            var TotalYellow = db.SpGetColor(color).FirstOrDefault();
            lblYellow.Text = TotalYellow.ToString();

            string color1 = "Red";

            var TotalRed = db.SpGetColor(color1).FirstOrDefault();
            lblRed.Text = TotalRed.ToString();

            //var totalyellow = db.SpGetColor("Yellow").ToString();
            //lblYellow.Text = totalyellow;

            //var totalRed = db.SpGetColor("Red").ToString();
            //lblRed.Text = totalRed;

        }
    }
}