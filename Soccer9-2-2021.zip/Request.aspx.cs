﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication1.BLL;


namespace WebApplication1
{
    public partial class Request : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            mthdFillRepeater();


            //  LinkButton lblStatus = Repeater1.Items[0].FindControl("BtnEdit") as LinkButton;
            //  var rec = db.tblMatchAssignRequests.FirstOrDefault();  

            //     if (rec.Status==true)
            //    {
            //         lblStatus.Text   = "Active";
            //    }
            //     else
            //    {
            //         lblStatus.Text = "Pending";
            //}

        }
        dbSoccerStateEntities db = new dbSoccerStateEntities();
        public void mthdFillRepeater()
        {
            if (Role.isRefree())
            {
                int id = int.Parse(Session["RefID"].ToString());
                Repeater1.DataSource = db.SpFillRepReq22(id).ToList().OrderByDescending(p => p.RequestID);
                Repeater1.DataBind();
            }
            else
            {

                //Repeater1.DataSource = db.SpFillRepeaterRequestMatch().ToList().OrderByDescending(p => p.RequestID);
                //Repeater1.DataBind();
            }
        }

        protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            switch (e.CommandName)
            {

                case ("Edit"):

                  
                    //==== Getting id of the selelected record(We have passed on link button's command argument property).
                    int id = Convert.ToInt32(e.CommandArgument);
                    HiddenField1.Value = id.ToString();
                   // tblMatchAssignRequest obj1 = db.tblMatchAssignRequests.FirstOrDefault(r => r.RequestID == id);
                     var row = db.tblMatchAssignRequests.Where(a => a.RequestID == id).FirstOrDefault();
                    // var rec = db.tblMatches.Where(p => p.MatchID == obj1.matchID).FirstOrDefault();
                   // tblMatch obj2 = db.tblMatches.FirstOrDefault(r => r.MatchID == obj1.matchID);


                  //  obj2.RefereeID = obj1.RequestTo;


                    row.Status = true;

                    db.SaveChanges();

             

                    break;


                
            }
            mthdFillRepeater();
        }

    }
}