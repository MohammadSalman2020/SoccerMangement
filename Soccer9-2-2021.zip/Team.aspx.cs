﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication1.BLL;

namespace WebApplication1
{
    public partial class Team : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblmsg.Visible = false;
            MTHDFillRepeater();
            BtnUpdate.Visible = false;
            lblDiv.Visible = false;
            DrpDiv.Visible = false;
            if(!IsPostBack ){
                FillDrops();
                FillDropDivision();
            }
          
          

        }
         public void FillDrops()
        {
            DrpAgeGroup.DataSource = db.SpFillDrpAgeGroup().ToList();
            DrpAgeGroup.DataTextField = "AgeGroupWithDiv";
            DrpAgeGroup.DataValueField = "AgeGroupID";
            DrpAgeGroup.DataBind();


        }
         public void FillDropDivision()
         {
             int ID = int.Parse(DrpAgeGroup.SelectedValue.ToString());
             DrpDiv.DataSource =  db.SpFillDrpDivision(ID).ToList();
             DrpDiv.DataTextField = "Division";
             DrpDiv.DataValueField = "AgeGroupID";
             DrpDiv.DataBind();


         }
        dbSoccerStateEntities db = new dbSoccerStateEntities();
        protected void BtnSubmit_Click(object sender, EventArgs e)
        {
            
            if (!Empty())
            {
                TeamBLL obj = new TeamBLL();
                obj.Add(int.Parse(DrpAgeGroup.SelectedValue.ToString()),TxtName.Text,DrpDiv.SelectedItem.ToString());
                db.SaveChanges();
                Clear();
                MTHDFillRepeater();
                lblmsg.Visible = true;
                lblmsg.Text = "Record Entered Successfully";
                lblmsg.ForeColor = System.Drawing.Color.Green;
            }
            else
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Fill All Fields";
                lblmsg.ForeColor = System.Drawing.Color.Green;
            }


        }
        public void MTHDFillRepeater()
        {
            Repeater1.DataSource = db.SpFillRepTeamUpdate1().ToList().OrderByDescending(p => p.TeamID);
            Repeater1.DataBind();

        }
        public bool Empty()
        {
            if (DrpAgeGroup.SelectedValue.Trim() == string.Empty || TxtName.Text.Trim() == string.Empty )
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Fill all fields";
                lblmsg.ForeColor = System.Drawing.Color.Red;
                return true;

            }
            else
            {
                return false;
            }
        }
        public void Clear()
        {
            
            TxtName.Text = "";
            
        }

      

        protected void DrpAgeGroup_SelectedIndexChanged(object sender, EventArgs e)
        {
            FillDropDivision();
        }

        protected void Repeater1_ItemCommand1(object source, RepeaterCommandEventArgs e)
        {
            switch (e.CommandName)
            {

                case ("Edit"):

                    //==== Getting id of the selelected record(We have passed on link button's command argument property).
                    int id = Convert.ToInt32(e.CommandArgument);
                    HiddenField1.Value = id.ToString();
                    tblTeam obj1 = db.tblTeams.FirstOrDefault(r => r.TeamID == id);


                    DrpAgeGroup.SelectedValue = obj1.AgeGroupID.ToString();
                    TxtName.Text = obj1.Name;



                    BtnSubmit.Visible = false;
                    BtnUpdate.Visible = true;


                    break;
            }
        }

        protected void BtnUpdate_Click1(object sender, EventArgs e)
        {
            try
            {

                int id = int.Parse(HiddenField1.Value);
                var row = db.tblTeams.Where(a => a.TeamID == id).FirstOrDefault();
                if (row != null)
                {





                    row.AgeGroupID = int.Parse(DrpAgeGroup.SelectedValue.ToString());
                    row.Name = TxtName.Text;


                    db.SaveChanges();



                    BtnSubmit.Visible = true;
                    BtnUpdate.Visible = false;

                    MTHDFillRepeater();

                    Clear();
                    lblmsg.Visible = true;
                    lblmsg.Text = "Record Updated Successfully";
                    lblmsg.ForeColor = System.Drawing.Color.Green;
                }

            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
        }

        }
    }
