﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.BLL
{
    public class TeamBLL
    {
        dbSoccerStateEntities db = new dbSoccerStateEntities();
        public void Add(int AgeGroupID, string Name,string Division)
        {
            tblTeam obj = new tblTeam();

            obj.AgeGroupID = AgeGroupID;
            obj.Name = Name;
            obj.Division = Division;
            

            db.tblTeams.Add(obj);
            db.SaveChanges();



        }
    }
}