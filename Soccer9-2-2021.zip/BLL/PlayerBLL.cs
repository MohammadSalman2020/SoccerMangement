﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.BLL
{
    public class PlayerBLL
    {

        dbSoccerStateEntities db = new dbSoccerStateEntities();
        public void Add(int TeamID, string FirstName,string LastName,string ShirtNo )
        {
            tblPlayer obj = new tblPlayer();

            obj.TeamID = TeamID;
            obj.FirstName = FirstName;
            obj.LastName = LastName;
            obj.ShirtNo = ShirtNo;


            db.tblPlayers.Add(obj);
            db.SaveChanges();



        }
    }
}