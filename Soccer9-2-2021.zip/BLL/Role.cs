﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


namespace WebApplication1.BLL
{
    public class Role
    {
        public static string RefreesAdmin = "1";
        public static string RefreeCordinator = "2";
        public static string Treasure = "3";
        public static string Refree = "4";
        public static bool isRefreeAdmin()
        {
            if (System.Web.HttpContext.Current.Session["RoleID"].ToString() == Role.RefreesAdmin) {
                
                
                return true;
            }
            else {
                return false;
            }
        }
        public static bool isRefreeCordinator()
        {
            if (System.Web.HttpContext.Current.Session["RoleID"].ToString() == Role.RefreeCordinator)
            {


                return true;
            }
            else
            {
                return false;
            }
        }
        public static bool isTreasure()
        {
            if (System.Web.HttpContext.Current.Session["RoleID"].ToString() ==Role.Treasure)
            {
                return true;
            }
            else
            {
                return false;
            }

        }
        public static bool isRefree()
        {
            if (System.Web.HttpContext.Current.Session["RoleID"].ToString() == Role.Refree)
            {
                return true;
            }
            else
            {
                return false;
            }

        }
    }

}