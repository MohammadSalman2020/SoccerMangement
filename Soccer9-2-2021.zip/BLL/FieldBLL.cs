﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.BLL
{
    public class FieldBLL
    {
        dbSoccerStateEntities db = new dbSoccerStateEntities();
        public void Add(string FieldName , float LenghtInYards , float WidthInYards , string FieldLocation)
        {
            tblField obj = new tblField();

            obj.FieldName = FieldName;
            obj.LenghtInYards = LenghtInYards;
            obj.WidhtInYards = WidthInYards;
            obj.FieldLocation = FieldLocation;

            db.tblFields.Add(obj);
            db.SaveChanges();



        }
    }
}