﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.BLL
{
    public class MatchBLL
    {
        dbSoccerStateEntities db = new dbSoccerStateEntities();
        public void Add(string MatchTitle,int FieldID,int AgeGroup,int TeamA ,int TeamB,DateTime Date,string Time)
        {
            tblMatch obj = new tblMatch();

            obj.MatchTitle= MatchTitle;
            obj.FieldID = FieldID;
            obj.AgeGroup = AgeGroup;
            obj.Team1 = TeamA;
            obj.Team2 = TeamB;
            obj.MatchDate = Date;
            obj.MatchTime = Time;



            db.tblMatches.Add(obj);
            db.SaveChanges();



        }
    }
}