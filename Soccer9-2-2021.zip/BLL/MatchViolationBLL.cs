﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.BLL
{
    public class MatchViolationBLL
    {
        dbSoccerStateEntities db = new dbSoccerStateEntities();

        public void Add(int MatchID, int PlayerID, string LeadUpToIncident, string Incident, string PositionDetail, string AbusiveLanguage, string AttBefore, string AttDuring, string AttAfter)
        {
            tblMatchViolation obj = new tblMatchViolation();
            obj.MatchID = MatchID;
            obj.PlayerID = PlayerID;
            obj.LeadUpToIncident = LeadUpToIncident;
            obj.Incident = Incident;
            obj.PositionDetail = PositionDetail;
            obj.AbusiveLanguage = AbusiveLanguage;
            obj.AttBefore = AttBefore;
            obj.AttDuring = AttDuring;
            obj.AttAfter = AttAfter;
            db.tblMatchViolations.Add(obj);
            db.SaveChanges();
        }
    }

}