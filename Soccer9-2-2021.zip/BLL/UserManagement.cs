﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.BLL
{
    public class UserManagement
    {
        dbSoccerStateEntities db = new dbSoccerStateEntities();
        public void Add(string Email, string Password, int RoleID,string Username) //, int RefID)
        {
            tblLogin obj = new tblLogin();

            obj.Email = Email;
            obj.C_Password = Password;
            obj.RoleID = RoleID;
            obj.Username = Username;
         //   obj.SystemUser = RefID;

            db.tblLogins.Add(obj);
            db.SaveChanges();
        }
    }
}