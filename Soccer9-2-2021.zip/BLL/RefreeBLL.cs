﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.BLL
{
    public class RefreeBLL
    {
        dbSoccerStateEntities db = new dbSoccerStateEntities();
        public void Add(string FirstName, string LastName , bool IsAvalaible ,int RefID  )
        {
            tblReferee obj = new tblReferee();

            obj.FirstName = FirstName;
            obj.LastName = LastName;
            obj.IsAvailable = IsAvalaible;
                    

            db.tblReferees.Add(obj);
            db.SaveChanges();



        }

      
    }
}