﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.BLL
{
    public class AgeBLL
    {
        dbSoccerStateEntities db = new dbSoccerStateEntities();
        public void Add(string AgeGroup , string Division , string Difficulty,int Rate)
        {
            tblAgeGroup obj = new tblAgeGroup();

            obj.AgeGroup = AgeGroup;
            obj.Division = Division;
            obj.Difficulty = Difficulty;
            obj.Rate = Rate;
            db.tblAgeGroups.Add(obj);
            db.SaveChanges();
        }
    }
}