﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


namespace WebApplication1.BLL
{
    
    public class Login
    {
        dbSoccerStateEntities obj = new dbSoccerStateEntities();
        public bool IsUser( string Email, string Password)
        {
            var rec = obj.tblLogins.Where(a => a.Email == Email && a.C_Password == Password).FirstOrDefault();
            if (rec != null)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public tblLogin GetUser(string email)
        {
            try
            {


                var rows = obj.tblLogins.Where(a => a.Email.Equals(email)).FirstOrDefault();
                return rows;


            }
            catch (Exception)
            {
                //log exception
                return null;

            }


        }
    }
}